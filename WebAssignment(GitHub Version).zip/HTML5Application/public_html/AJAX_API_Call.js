/* 
 *  Created on : Dec 10, 2021, 2:40:41 PM
 *  Author     : eqw5281
 */

const xhr = new XMLHttpRequest(); // Creates XMLHttpRequest (XHR) object
const url = "THIS URL HAS BEEN REMOVED BY AUTHOR"; // Target url stored as variable

// Execute function to create list of news topics
runRequest('topics');

/*
 * Function sends XML Http Request. Then calls function to
 * extract desired data.
 */
function runRequest(load, selected_topic){
    // Execute function only once xhr element is loaded 
    xhr.onload = function(){
        
        // If xhr object is received...
        if (this.status === 200){
                // ...parse it to JSON
                var resObj = JSON.parse(this.responseText);
                
                // Execute extractData function
                extractData(resObj, load, selected_topic);
        }
        
        // Do if XML request fails
        else {
            console.log("XML Request Failed");
        }
    };
    xhr.open('GET', url);
    xhr.send();
};

/*
 * Parameters:
 * resObj - Received request in form of JSON object
 * load - Data being loaded to website (topics or articles)
 * selected_topic - Loads articles of specified topic.
 *      Only used when loading articles. Can be null.
 *      
 * Function extracts news topics or articles and creates
 * HTML elements out of them dynaimcally. Also enables
 * created ul elements to call onClick function when
 * clicked on.
 */
function extractData(resObj, load, selected_topic){
    var items = []; // Temporarily holds extracted data from resObj
    
    // if loading topics...
    if(load === 'topics'){
        
        const nav_bar = document.getElementById("topics_nav_bar"); // Gets HTML element to place topics into
        nav_bar.innerHTML = "<h1 id = 'topics_nav_bar_header'>Today's Topics</h1>"; // Replaces header after deletion
        var topics = ''; // Records read topics to prevent repeats
        
        // ...Extract topics from resObj and place into items array
        resObj['response']['results'].forEach(function(item){items.push
        ({sectionName: item.sectionName});
        });
        
        // Iterate through topics and create ul elements
        for (i = 0; i < items.length; i++){
            
            // If topic is not a repeat
            if (topics.includes(items[i].sectionName) === false){
                
                // Record new topic was now read
                topics += (items[i].sectionName);
               
                // Create a ul element with the topic as its id
                const ul = document.createElement('ul');
                ul.setAttribute("id", (items[i].sectionName));
                
                // Imbeds onClick() into element and executes
                // when element is clicked on
                ul.addEventListener('click', onClick);
                
                // Creates array of all ul element ids (Essentially is a list of all news topics)
                const ulElements = Array.from(document.querySelectorAll('ul'));
               
                // Make topic visible on webpage
                ul.innerHTML = (items[i].sectionName);
               
               // Add ul to navigation bar
               nav_bar.appendChild(ul);
           }
       }
    }
    
    // If loading articles...
    else if (load === 'articles'){
        
        const content = document.getElementById("topics_cont"); // Gets HTML element to place articles into
        content.innerHTML = ""; // Clears any articles currently in container
        
        // ...Extract topics, name, and url from resObj and place into items array
        resObj['response']['results'].forEach(function(item){items.push
        ({sectionName: item.sectionName, webTitle: item.webTitle, webUrl: item.webUrl});
        });
        
        // Iterate through selected data and create 'a' elements
        for(i = 0; i < items.length; i++){
            
            // If article matches selected_topic...
            if (items[i].sectionName === selected_topic){
                
                // ...Create 'a' element
                const a = document.createElement("a");
                const li = document.createElement("li");
                
                // Imbed hyperlink of article
                a.href = (items[i].webUrl);
                
                // Make article title visible
                a.textContent = items[i].webTitle;
                
                // Add element to webpage
                li.appendChild(a);
                content.appendChild(li);
            }
        }
    }
}

/*
 * Function is dynamically imbedded into created
 * ul elements. Executes when element is clicked
 * on. Upon execution, function gets the id of
 * the ul element and stores it in a local
 * variable "selected_topic". It then executes
 * runRequest(), sending the topic with it to
 * populate the page with articles of that topic.
 */
function onClick(event) {
    const selected_topic = (event.currentTarget).id;
    runRequest('articles', selected_topic);
};