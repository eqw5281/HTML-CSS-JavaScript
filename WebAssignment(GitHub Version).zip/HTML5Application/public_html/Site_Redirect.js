/* 
 *  Created on : Dec 10, 2021, 2:40:41 PM
 *  Author     : eqw5281
 */

// Opens The Guardian in new window
function toGuardian(){
        window.open('https://www.theguardian.com');
    }

// Opens LinkedIn in new window
function toLinkedIn(){
        console.log("THIS LINK HAS BEEN REMOVED BY THE AUTHOR");
    }

// Opens Github in new window
function toGitHub(){
        window.open('https://github.com/eqw5281/Games');
    }

// Opens WordPress in new window
function toWordpress(){
        console.log("THIS LINK HAS BEEN REMOVED BY THE AUTHOR");
    }